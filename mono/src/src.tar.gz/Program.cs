﻿using System;
using System.Collections.Generic;

namespace CSharpConsol
{
    class MainClass
    {
        private static void create(DBConnect person)
        {
            string query = String.Format("CREATE TABLE `{0}`.person (", person.DATABASE);
            query += " id INT PRIMARY KEY auto_increment,";
            query += " name varchar(10) NOT NULL,";
            query += " age INT NOT NULL";
            query += " );";
            person.Create(query, true);
        }
        private static void insert(DBConnect person)
        {
            string baseStatement = String.Format("INSERT INTO `{0}`.person (id, name, age) VALUES", person.DATABASE);

            List<string> values = new List<string>();
            Random r = new Random();

            foreach(string name in new string[] { "Adam", "Bob", "Calvin"})
            {
                string x = String.Format("(default, '{0}', {1})", name, r.Next(21, 65));
                values.Add(x);
            }
            person.Insert(String.Format("{0}{1};", baseStatement, String.Join(",", values.ToArray())));

        }
        public static void Main(string[] args)
        {
            const string database = "odbc-simple";

            DBConnect person = new DBConnect(database);
            //person.Drop();
            //person.Create(String.Format("CREATE DATABASE `{0}`;", database));
            //create(person);
            //person.CreateConnect(true);
            person.Truncate();
            insert(person);
            person.Update("UPDATE person SET name='Cain' WHERE id=1;");
            person.Delete("DELETE FROM person WHERE id=2;");
        }
    }
}
