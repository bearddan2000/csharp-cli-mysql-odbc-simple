﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
namespace CSharpConsol
{
    public class DBConnect
    {
        const string SERVER = "maria";
        //const string SERVER = "localhost";
        const string USER = "maria";
        const string PASSWORD = "pass";

        public string DATABASE { get; set;}

        string connectionStr = "";
        MySql.Data.MySqlClient.MySqlConnection conn;

        public DBConnect(string db)
        {
            DATABASE = db;
            CreateConnect();
        }
        public void CreateConnect()
        {
            connectionStr = String.Format("SERVER={0};", SERVER);
                connectionStr += String.Format("DATABASE={0};", DATABASE);
            connectionStr += String.Format("UID={0};", USER);
            connectionStr += String.Format("PASSWORD={0};", PASSWORD);
            conn = new MySql.Data.MySqlClient.MySqlConnection(connectionStr);
        }
        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        Console.WriteLine("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        Console.WriteLine("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        private void NonQuery(string query)
        {
            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, conn);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
            }
        }
        private void Print(string action, string query, bool IsTable = false)
        {
            Console.WriteLine("<=======================>");

            Console.WriteLine("query {0}", query);
            if (IsTable)
            {
                Console.WriteLine("TABLE after {0}", action);
                this.Select(query);
            }
            else
            {
                Console.WriteLine("SELECT after {0}", action);
                this.Select();
            }
        }
        public void Truncate()
        {
            this.NonQuery("TRUNCATE TABLE person;");
        }
        // Create database and table
        public void Create(string query, bool IsTable=false)
        {
            Console.WriteLine("<=======================>");
            Console.WriteLine("query {0}", query);
            this.NonQuery(query);
            if (IsTable) {
                query = "SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, " +
                    "IS_NULLABLE " +
                    "FROM INFORMATION_SCHEMA.COLUMNS " +
                    "WHERE TABLE_NAME LIKE 'person';";
                Print("DESCRIBE", query, IsTable);
            }
        }
        // Drop database
        public void Drop()
        {
            string query = String.Format("DROP DATABASE IF EXISTS `{0}`;", DATABASE);
            Console.WriteLine("<=======================>");
            Console.WriteLine("query {0}", query);
            this.NonQuery(query);
        }
        //Insert statement
        public void Insert(string query)
        {
            this.NonQuery(query);
            this.Print("Insert", query);
        }

        //Update statement
        public void Update(string query)
        {
            this.NonQuery(query);
            this.Print("Update", query);
        }

        //Delete statement
        public void Delete(string query)
        {
            this.NonQuery(query);
            this.Print("Delete", query);
        }

        //Select statement
        public void Select(string query="")
        {
            if(String.IsNullOrEmpty(query))
                query = String.Format("SELECT * FROM `{0}`.person;", this.DATABASE);

            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, conn);

                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();

                //Get column headers
                for (int i = 0; i < dataReader.FieldCount; i++)
                    Console.Write("{0}\t", dataReader.GetName(i));

                //Make a seperator
                Console.WriteLine("");
                Console.WriteLine("---------------------");

                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    List<string> fields = new List<string>();

                    //loop thru a row column by column
                    for (int i = 0; i < dataReader.FieldCount; i++)
                        fields.Add("" + dataReader[i]);

                    //seperat fields with tab
                    Console.Write(String.Join("\t", fields.ToArray()));
                    //Make a seperator
                    Console.WriteLine("");
                    Console.WriteLine("---------------------");
                }

                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

            }
        }

        public void CloseConnection()
        {
            try { conn.Close(); }
            catch(MySqlException e) { Console.WriteLine(e.Message); }
        }
    }
}
